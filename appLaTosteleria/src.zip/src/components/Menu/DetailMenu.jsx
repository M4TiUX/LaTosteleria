import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useTranslation } from "react-i18next";
import {
  Box,
  Button,
  Card,
  CardContent,
  CardMedia,
  Chip,
  Grid,
  Stack,
  Typography,
} from "@mui/material";

import RestaurantMenuOutlinedIcon from "@mui/icons-material/RestaurantMenuOutlined";
import MenuService from "../../services/MenuService";
import { formatMenuDate, formatMenuTime } from "./menuUtils";
import PropTypes from "prop-types";

function MenuItemCard({ item, tipo }) {
  return (
    <Card
      sx={{
        height: "100%",
        borderRadius: "8px",
        boxShadow: 2,

        backgroundColor: tipo === "combo" ? "#fff8ef" : "#fff",

        overflow: "hidden",

        display: "flex",
        flexDirection: "column",

        transition: "0.25s",

        "&:hover": {
          transform: "translateY(-4px)",

          boxShadow: 5,
        },
      }}
    >
      {/* Imagen */}
      {item.imagen ? (
        <CardMedia
          component="img"
          height="180"
          image={`/images/${item.imagen}`}
          alt={item.nombre}
          sx={{
            objectFit: "cover",
          }}
        />
      ) : (
        <Box
          sx={{
            height: 180,

            bgcolor: "action.hover",

            display: "flex",

            justifyContent: "center",

            alignItems: "center",
          }}
        >
          <RestaurantMenuOutlinedIcon
            sx={{
              fontSize: 60,
              color: "text.disabled",
            }}
          />
        </Box>
      )}

      <CardContent
        sx={{
          flexGrow: 1,
        }}
      >
        <Stack spacing={1}>
          <Typography variant="subtitle1" fontWeight={700}>
            {item.nombre}
          </Typography>

          <Typography
            variant="body2"
            color="text.secondary"
            sx={{
              display: "-webkit-box",

              WebkitBoxOrient: "vertical",

              WebkitLineClamp: 3,

              overflow: "hidden",
            }}
          >
            {item.descripcion}
          </Typography>

          <Typography variant="subtitle2" fontWeight={700} color="primary">
            ₡{" "}
            {new Intl.NumberFormat("es-CR", {
              maximumFractionDigits: 0,
            }).format(Number(item.precio ?? 0))}
          </Typography>
        </Stack>
      </CardContent>
    </Card>
  );
}

MenuItemCard.propTypes = {
  item: PropTypes.object.isRequired,
  tipo: PropTypes.string.isRequired,
};

export function DetailMenu() {
  const { id } = useParams();

  const { t } = useTranslation();

  const [menu, setMenu] = useState(null);

  const [loaded, setLoaded] = useState(false);

  const [error, setError] = useState(null);

  useEffect(() => {
    MenuService.getMenuById(id)
      .then((response) => {
        setMenu(response.data);

        setLoaded(true);
      })
      .catch((err) => {
        setError(err);
        setLoaded(true);
      });
  }, [id]);

  if (!loaded) {
    return <p>{t("menus.detail.loading")}</p>;
  }

  if (error) {
    return <p>Error: {error.message}</p>;
  }

  if (!menu) {
    return <p>{t("menus.detail.notFound")}</p>;
  }

  return (
    <Box>
      {/* Encabezado */}
      <Stack
        direction={{
          xs: "column",
          md: "row",
        }}
        justifyContent="space-between"
        spacing={2}
        sx={{ mb: 3 }}
      >
        <Box>
          <Typography
            variant="h3"
            sx={{
              mb: 1,
              fontWeight: 700,
            }}
          >
            {menu.nombre_menu}
          </Typography>

          <Typography variant="body1" color="text.secondary" sx={{ mb: 1 }}>
            {t("menus.detail.availability", {
              startDate: formatMenuDate(menu.fecha_inicio),

              startTime: formatMenuTime(menu.hora_inicio),

              endDate: formatMenuDate(menu.fecha_fin),

              endTime: formatMenuTime(menu.hora_fin),
            })}
          </Typography>

          <Chip
            label={
              Number(menu.activo) === 1
                ? t("menus.status.activeMenu")
                : t("menus.status.inactiveMenu")
            }
            color={Number(menu.activo) === 1 ? "success" : "default"}
            size="small"
          />
        </Box>

        <Stack direction="row" spacing={1.5} alignItems="flex-start">
          <Button
            component={Link}
            to="/menu"
            variant="outlined"
            sx={{
              textTransform: "none",
            }}
          >
            {t("menus.detail.back")}
          </Button>
        </Stack>
      </Stack>

      {/* Imagen principal */}
      {menu.imagen ? (
        <Box
          component="img"
          src={`/images/${menu.imagen}`}
          alt={menu.nombre_menu}
          sx={{
            width: "100%",
            maxWidth: 650,

            height: {
              xs: 200,
              sm: 240,
              md: 280,
            },

            objectFit: "cover",
            display: "block",

            borderRadius: 3,
            boxShadow: 3,

            mb: 4,
          }}
        />
      ) : (
        <Box
          sx={{
            width: "100%",
            maxWidth: 1000,

            height: {
              xs: 250,
              sm: 360,
              md: 450,
            },

            bgcolor: "action.hover",

            display: "flex",

            justifyContent: "center",

            alignItems: "center",

            borderRadius: 3,

            mb: 4,
          }}
        >
          <RestaurantMenuOutlinedIcon
            sx={{
              fontSize: 100,
              color: "text.disabled",
            }}
          />
        </Box>
      )}

      {/* Categorías */}
      {menu.categorias?.map((category) => (
        <Box
          key={category.categoria_nombre}
          sx={{
            mb: 4,
          }}
        >
          <Typography
            variant="h5"
            fontWeight={700}
            sx={{
              mb: 2,
            }}
          >
            {category.categoria_nombre}
          </Typography>

          {/* Productos */}
          {category.productos?.length > 0 && (
            <>
              <Typography
                variant="subtitle1"
                fontWeight={700}
                sx={{
                  mb: 1,
                }}
              >
                {t("menus.common.products")}
              </Typography>

              <Grid
                container
                spacing={2}
                sx={{
                  mb: category.combos?.length > 0 ? 3 : 0,
                }}
              >
                {category.productos.map((item) => (
                  <Grid item xs={12} sm={6} md={4} key={`producto-${item.id}`}>
                    <MenuItemCard item={item} tipo="producto" />
                  </Grid>
                ))}
              </Grid>
            </>
          )}

          {/* Combos */}
          {category.combos?.length > 0 && (
            <>
              <Typography
                variant="subtitle1"
                fontWeight={700}
                sx={{
                  mb: 1,
                }}
              >
                {t("menus.common.combos")}
              </Typography>

              <Grid container spacing={2}>
                {category.combos.map((item) => (
                  <Grid item xs={12} sm={6} md={4} key={`combo-${item.id}`}>
                    <MenuItemCard item={item} tipo="combo" />
                  </Grid>
                ))}
              </Grid>
            </>
          )}
        </Box>
      ))}
    </Box>
  );
}
